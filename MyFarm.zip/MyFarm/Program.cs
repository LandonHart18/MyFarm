﻿using System;

namespace MyFarm
{
	class Program
	{
		//to keep Main clean i've added a menu class
		static void Main()
		{	try
            {
				Menu menu = new Menu();
				menu.AnimalIndex();
			}
            catch (Exception Ex)
            {
				Console.WriteLine(Ex);
			}
		}
	}
}
