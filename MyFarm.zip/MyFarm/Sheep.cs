﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyFarm
{
	public class Sheep
	{
		public string Speak()
		{
			return "Hello, my name is Mr. La Fluff, and I am a Sheep. I say Bahahaha!";
		}

		public string Eat()
		{
			return "I eat grass!";
		}

		public string Sleep()
		{
			return "I sleep next to the cows!";
		}

		public string Product()
		{
			return "I provide fabric for clothes!";
		}
	}
}
