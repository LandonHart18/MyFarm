﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyFarm
{
	public class Pigs
	{
		public string Speak()
		{
			return "Hello, my name is Jonas, and I am a Pig. I say OinkOink!";
		}

		public string Eat()
		{
			return "I eat anyhting!";
		}

		public string Sleep()
		{
			return "I sleep in the mud in the pig pin!";
		}

		public string Product()
		{
			return "I produce ham and bacon!";
		}
	}
}
