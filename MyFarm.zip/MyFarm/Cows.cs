﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyFarm
{
	public class Cows
	{
		public string Speak()
		{
			return "Hello, my name is Molly, and I am a Cow. I say Moo!";
		}

		public string Eat()
		{
			return "I eat grass!";
		}

		public string Sleep()
		{
			return "I sleep in the pastures under the stars!";
		}

		public string Product() 
		{
			return "I produce milk for everyone to enjoy!";
		}
	}
}
