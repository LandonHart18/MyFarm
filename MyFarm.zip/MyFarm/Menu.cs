﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyFarm
{
	public class Menu
	{
		public void AnimalIndex() 
		{
			//Main Menu used to select which animal to get info about them.
			int caseSwitch;
			Console.WriteLine("Please select which animal you want to learn about?\n\n1. Molly\n\n2. Mr. La Fluff\n\n3. Ronaldo\n\n4. Jonas\n\n5. Exit");
			string input = Console.ReadLine();
			while (int.TryParse(input, out caseSwitch) == false || caseSwitch < 1 || caseSwitch > 5)
			{

				Console.WriteLine("Please pick a number between 1 and 5!");
				input = Console.ReadLine();

			}

			switch (caseSwitch)
			{
				case 1:
					Cows Cows = new Cows();
					Cows.Speak();
					Cows.Eat();
					Cows.Sleep();
					Cows.Product();
					AnimalIndex();
					break;
				case 2:
					Sheep Sheep = new Sheep();
					Sheep.Speak();
					Sheep.Eat();
					Sheep.Sleep();
					Sheep.Product();
					AnimalIndex();
					break;
				case 3:
					Chicken Chicken = new Chicken();
					Chicken.Speak();
					Chicken.Eat();
					Chicken.Sleep();
					Chicken.Product();
					AnimalIndex();
					break;
				case 4:
					Pigs Pigs = new Pigs();
					Pigs.Speak();
					Pigs.Eat();
					Pigs.Sleep();
					Pigs.Product();
					AnimalIndex();
					break;
				case 5:
					Console.WriteLine("Thanks for learning about our animals! Bye!");
					break;
			}
		}
	}
}
