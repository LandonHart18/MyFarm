﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyFarm
{
	public class Chicken
	{
		public string Speak()
		{
			return "Hello, my name is Ronaldo, and I am a Chicken. I say CluckCluck!";
		}

		public string Eat()
		{
			return "I eat chicken feed!";
		}

		public string Sleep()
		{
			return "I sleep inside my palace called the chicken coop!";
		}

		public string Product()
		{
			return "I produce eggs!";
		}
	}
}
